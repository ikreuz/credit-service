import axios from "axios";
const azure = 'http://creditandsaving.azurewebsites.net/api'
// Customer
const netCustomersPost = azure + '/Customers/insert'
const netCustomersPut = azure + '/Customers/update'
// const netCustomersDelete = azure+'/Customers/delete/'
// const netCustomersGet = azure+'/Customers/get/';
const netCustumersGetAll = azure + '/Customers/getall'
// Roles
// const netRolesPost = azure+'/Roles/insert'
// const netRolesPut = azure+'/Roles/update'
// const netRolesDelete = azure+'/Roles/delete/'
// const netRolesGet = azure+'/Roles/get/';
const netRolesGetAll = azure + '/Roles/getall'
// Tower => Master ID, Auth
// const netTowerPost = azure+'/Tower/insert'
// const netTowerPut = azure+'/Tower/update'
// const netTowerDelete = azure+'/Tower/delete/'
// const netTowerGet = azure+'/Tower/get/';
const netTowerGetAll = azure + '/Tower/getall'
// Transaction
// const netTransactionPost = azure+'/Transaction/insert'
// const netTransactionPut = azure+'/Transaction/update'
// const netTransactionDelete = azure+'/Transaction/delete/'
// const netTransactionGet = azure+'/Transaction/get/';
// const netTransactionGetAll = azure+'/Transaction/getall'
// Transaction Credit
// const netTransactionCreditPost = azure+'/TransactionCredit/insert'
// const netTransactionCreditPut = azure+'/TransactionCredit/update'
// const netTransactionCreditDelete = azure+'/TransactionCredit/delete/'
// const netTransactionCreditGet = azure+'/TransactionCredit/get/';
const netTransactionCreditGetAll = azure + '/TransactionCredit/getall'
// Transaction Saving
const netTransactionSavingPost = azure + '/TransactionSaving/insert'
// const netTransactionSavingPut = azure+'/TransactionSaving/update'
// const netTransactionSavingDelete = azure+'/TransactionSaving/delete/'
// const netTransactionSavingGet = azure+'/TransactionSaving/get/';
const netTransactionSavingGetAll = azure + '/TransactionSaving/getall'
// Users
// const netUsersPost = azure+'/Users/insert'
// const netUsersPut = azure+'/Users/update'
// const netUsersDelete = azure+'/Users/delete/'
// const netUsersGet = azure+'/Users/get/';
const netUsersGetAll = azure + '/Users/getall'
// Credit Account
// const netCreditAccountGet = azure+'/CreditAccount/get/';
// Saving Account
// const netSavingAccountGet = azure+'/SavingAccount/get/';
//
export default {
  state: {
    apiTowerGetAll: [],
    apiCustomersGetAll: [],
    apiRolesGetAll: [],
    apiUsersGetAll: [],
    apiTransactionGetAll: [],
    apiTransactionCreditGetAll: [],
    apiTransactionSavingGetAll: [],

  },
  getters: {
    getEpApiTowerGetAll(state) {
      return state.apiTowerGetAll;
    },
    getEpApiCustomersGetAll(state) {
      return state.apiCustomersGetAll;
    },
    getEpApiRolesGetAll(state) {
      return state.apiRolesGetAll;
    },
    getEpApiUsersGetAll(state) {
      return state.apiUsersGetAll;
    },
    getEpApiTransactionGetAll(state) {
      return state.apiTransactionGetAll;
    },
    getEpApiTransactionCreditGetAll(state) {
      return state.apiTransactionCreditGetAll;
    },
    getEpApiUsersTrasnsactionSavingAll(state) {
      return state.apiTransactionSavingGetAll;
    },
    postEpCustomers() {
      return netCustomersPost;
    },
    putEpCustomers() {
      return netCustomersPut;
    },
    postEpTranasctionSaving() {
      return netTransactionSavingPost;
    },
    getEpCustomers() {
      return netCustumersGetAll;
    },
    getEpTransactionCredit() {
      return netTransactionCreditGetAll;
    },
    getEpTransactionSaving() {
      return netTransactionSavingGetAll;
    },
    // getEpTransaction() {
    //   return netTransactionGetAll;
    // },
    // getEpCreditAccount() {
    //   return netCreditAccountGet;
    // },
    // getEpSavingAccount() {
    //   return netSavingAccountGet;
    // }
  },
  mutations: {
    SET_API_TOWER_GET_ALL(state, payload) {
      state.apiTowerGetAll = payload;
    },
    SET_API_CUSTOMERS_GET_ALL(state, payload) {
      // console.log("set:: "+typeof(payload));
      // console.log("set:: "+payload.Data);
      state.apiCustomersGetAll = payload;
    },
    SET_API_ROLES_GET_ALL(state, payload) {
      state.apiRolesGetAll = payload;
    },
    SET_API_USERS_GET_ALL(state, payload) {
      state.apiUsersGetAll = payload;
    },
    SET_API_TRANSACTION_GET_ALL(state, payload) {
      state.apiTransactionGetAll = payload;
    },
    SET_API_TRANSACTION_CREDIT_GET_ALL(state, payload) {
      state.apiTransactionCreditGetAll = payload;
    },
    SET_API_TRANSACTION_SAVING_GET_ALL(state, payload) {
      state.apiTransactionSavingGetAll = payload;
    },
  },
  actions: {
    // ALL GET ALL
    async axnApi({ dispatch }) {
      try {
        await axios
          .all([
            axios.get(netTowerGetAll),
            axios.get(netRolesGetAll),
            axios.get(netUsersGetAll),
            axios.get(netCustumersGetAll),
            // axios.get(netTransactionGetAll),
            axios.get(netTransactionCreditGetAll),
            axios.get(netTransactionSavingGetAll),
          ])
          .then(
            axios.spread(function (
              part1, part2, part3, part4, part6, part7) {
              dispatch("axnTowerGetAll", part1.data);
              dispatch("axnRolesGetAll", part2.data);
              dispatch("axnUsersGetAll", part3.data);
              dispatch("axnCustomersGetAll", part4.data);
              // dispatch("axnTransactionGetAll", part5.data);
              dispatch("axnTransactionCreditGetAll", part6.data);
              dispatch("axnTransactionSavingGetAll", part7.data);
            })
          );
      } catch (error) {
        console.log(error);
      }
    },
    async axnTowerGetAll({ commit }, payload) {
      commit("SET_API_TOWER_GET_ALL", payload);
    },
    async axnRolesGetAll({ commit }, payload) {
      commit("SET_API_ROLES_GET_ALL", payload);
    },
    async axnUsersGetAll({ commit }, payload) {
      commit("SET_API_USERS_GET_ALL", payload);
    },
    async axnCustomersGetAll({ commit }, payload) {
      commit("SET_API_CUSTOMERS_GET_ALL", JSON.stringify(payload));
    },
    // async axnTransactionGetAll({ commit }, payload) {
    //   commit('SET_API_TRANSACTION_GET_ALL', payload)
    // },
    async axnTransactionCreditGetAll({ commit }, payload) {
      commit('SET_API_TRANSACTION_CREDIT_GET_ALL', payload)
    },
    async axnTransactionSavingGetAll({ commit }, payload) {
      commit('SET_API_TRANSACTION_SAVING_GET_ALL', payload)
    }
  },
};
